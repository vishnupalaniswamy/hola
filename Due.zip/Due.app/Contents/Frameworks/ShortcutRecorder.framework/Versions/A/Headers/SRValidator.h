//
//  Copyright 2006 ShortcutRecorder Contributors
//  CC BY 4.0
//

#import <Cocoa/Cocoa.h>

#import <ShortcutRecorder/SRRecorderControl.h>


NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(ValidatorDelegate)
@protocol SRValidatorDelegate;

/*!
 Validate shortcut by checking whether it is taken by other parts of the application and system.
 */
NS_SWIFT_NAME(Validator)
@interface SRValidator : NSObject <SRRecorderControlDelegate>

@property (nullable, weak) NSObject<SRValidatorDelegate> *delegate;

- (instancetype)initWithDelegate:(nullable NSObject<SRValidatorDelegate> *)aDelegate NS_DESIGNATED_INITIALIZER;

/*!
 Check whether shortcut is valid.

 @return YES if shortcut is valid.

 @discussion
 Key is checked in the following order:
     1. Delegate's shortcutValidator:isShortcutValid:reason:
     2. If delegate allows, system-wide shortcuts are checked
     3. If delegate allows, application menu it checked

 @seealso SRValidatorDelegate
 */
- (BOOL)validateShortcut:(SRShortcut *)aShortcut error:(NSError * _Nullable *)outError NS_SWIFT_NAME(validateShortcut(_:));

/*!
 Check whether delegate allows the shortcut.

 @return YES if shortcut is valid.

 @discussion Defaults to YES if delegate does not implement the method.
 */
- (BOOL)validateShortcutAgainstDelegate:(SRShortcut *)aShortcut error:(NSError * _Nullable *)outError;

/*!
 Check whether shortcut is taken by system-wide shortcuts.

 @return YES if shortcut is valid.

 @seealso SRValidatorDelegate/shortcutValidatorShouldCheckSystemShortcuts:
 */
- (BOOL)validateShortcutAgainstSystemShortcuts:(SRShortcut *)aShortcut error:(NSError * _Nullable *)outError;

/*!
 Check whether shortcut is taken by a menu item.

 @return YES if shortcut is valid.

 @seealso SRValidatorDelegate/shortcutValidatorShouldCheckMenu:
 */
- (BOOL)validateShortcut:(SRShortcut *)aShortcut againstMenu:(NSMenu *)aMenu error:(NSError * _Nullable *)outError NS_SWIFT_NAME(validateShortcut(_:againstMenu:));

@end


@interface SRValidator(Deprecated)

- (BOOL)isKeyCode:(unsigned short)aKeyCode andFlagsTaken:(NSEventModifierFlags)aFlags error:(NSError * _Nullable *)outError __attribute__((deprecated("", "validateShortcut:error:"))) NS_SWIFT_UNAVAILABLE("validateShortcut(_:)");
- (BOOL)isKeyCode:(unsigned short)aKeyCode andFlagTakenInDelegate:(NSEventModifierFlags)aFlags error:(NSError * _Nullable *)outError __attribute__((deprecated("", "validateShortcutAgainstDelegate:error:"))) NS_SWIFT_UNAVAILABLE("validateShortcutAgainstDelegate(_:)");
- (BOOL)isKeyCode:(unsigned short)aKeyCode andFlagsTakenInSystemShortcuts:(NSEventModifierFlags)aFlags error:(NSError * _Nullable *)outError __attribute__((deprecated("", "validateShortcutAgainstSystemShortcuts:error:"))) NS_SWIFT_UNAVAILABLE("Use validateShortcutAgainstSystemShortcuts(_:)");
- (BOOL)isKeyCode:(unsigned short)aKeyCode andFlags:(NSEventModifierFlags)aFlags takenInMenu:(NSMenu *)aMenu error:(NSError * _Nullable *)outError __attribute__((deprecated("", "validateShortcut:againstMenu:error:"))) NS_SWIFT_UNAVAILABLE("Use validateShortcut(_:againstMenu:)");

@end


@protocol SRValidatorDelegate

@optional

/*!
 Ask the delegate if the shortcut is valid.

 @param aValidator The validator that is validating the shortcut.

 @param aShortcut The shortcut to validate.

 @param outReason If the delegate decides that the shortcut is invalid, it may pass out an error message.

 @return YES if shortcut is valid; otherwise, NO.
 */
- (BOOL)shortcutValidator:(SRValidator *)aValidator isShortcutValid:(SRShortcut *)aShortcut reason:(NSString * _Nullable * _Nonnull)outReason;

/*!
    Same as -shortcutValidator:isShortcutValid:reason: but return value is flipped. I.e. YES means shortcut is invalid.
 */
- (BOOL)shortcutValidator:(SRValidator *)aValidator isKeyCode:(unsigned short)aKeyCode andFlagsTaken:(NSEventModifierFlags)aFlags reason:(NSString * _Nullable * _Nonnull)outReason __attribute__((deprecated("", "shortcutValidator:isShortcutValid:reason:")));

/*!
 Ask the delegate whether validator should check key equivalents of app's menu items.

 @param aValidator The validator that is validating the shortcut.

 @return YES if the validator should check key equivalents of app's menu items; otherwise, NO.

 @discussion If it is not implemented, checking proceeds as if this method had returned YES.
 */
- (BOOL)shortcutValidatorShouldCheckMenu:(SRValidator *)aValidator;

/*!
 Ask the delegate whether it should check system shortcuts.

 @param aValidator The validator that is validating the shortcut.

 @return YES if the validator should check system shortcuts; otherwise, NO.

 @discussion If it is not implemented, checking proceeds as if this method had returned YES.
 */
- (BOOL)shortcutValidatorShouldCheckSystemShortcuts:(SRValidator *)aValidator;

/*!
 Ask the delegate whether it should use ASCII representation of a key code for error messages.

 @param aValidator The validator that is validating the shortcut.

 @return YES if the validator should use ASCII representation; otherwise, NO.

 @discussion If it is not implemented, ASCII representation of a key code is used.
 */
- (BOOL)shortcutValidatorShouldUseASCIIStringForKeyCodes:(SRValidator *)aValidator;

@end


@interface NSMenuItem (SRValidator)

/*!
    Full path to the menu item. E.g. "Window → Zoom"
 */
- (NSString *)SR_path;

@end

NS_ASSUME_NONNULL_END
