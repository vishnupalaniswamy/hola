
safari.extension.dispatchMessage("load")

safari.self.addEventListener("message", ({name, message}) => {
  const handler = messageHandlers[name]
  if (handler) handler(message)
})

const fileHelpers = {
  extensionFromFilePath: (filePath) => {
    return filePath.split('.').reverse()[0]
  },
  nicedFilePath: (fileName, domain) => {
    var path = fileName
    if (domain) path += ' ← ' + domain
    return path
  },
  valuesFromFilePath: (filePath) => {
    var comps = filePath.split('/')
    const fileName = comps.reverse()[0]
    comps.shift()
    const domain = comps[0]
    return [fileName, domain]
  },
}

const scriptHelpers = {
  inject: (content) => {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        eval(content)
      })
    } else {
      eval(content)
    }
  },
  execute: (content) => {
    eval(content)
  },
}

const styleHelpers = {
  idForFileNameDomain: (fileName, domain) => {
    var id = fileName.replace('.css', '')
    if (domain) id += "__" + domain
    id = id.replaceAll('.', '_')
    return "_tamperish__" + id
  },
  inject: (identifier, content) => {
    const elm = document.getElementById(identifier)
    if (elm) return
    const node = document.createElement("style")
    node.id = identifier
    node.textContent = content
    document.head.appendChild(node)
  },
  remove: (identifier) => {
    const elm = document.getElementById(identifier)
    if (elm) elm.remove()
  },
  reinject: (identifier, content) => {
    styleHelpers.remove(identifier)
    styleHelpers.inject(identifier, content)
  },
}

const messageHandlers = {
  onload: message => {
    var files = []
    Object.entries(message).forEach(([filePath, content]) => {
      const [fileName, domain] = fileHelpers.valuesFromFilePath(filePath)
      files.push({fileName: fileName, domain: domain, content: content})
    })
    files = files.sort((a,b) => a.fileName >= b.fileName)
    files.forEach((file) => {
      const fileName = file.fileName
      const domain = file.domain
      const content = file.content
      const fileType = fileHelpers.extensionFromFilePath(fileName)
      if (!fileType) return
      const handler = fileTypeHandlers[fileType]
      if (!handler) return
      const niceFilePath = fileHelpers.nicedFilePath(fileName, domain)
      console.log(`[Tamperish] Injecting ${niceFilePath}`)
      handler(fileName, domain, content)
    })
  },
  injectScript: (filePath, content) => {
    scriptHelpers.inject(content)
  },
  injectStyle: (filePath, content) => {
    const [fileName, domain] = fileHelpers.valuesFromFilePath(filePath)
    const ident = styleHelpers.idForFileNameDomain(fileName, domain)
    styleHelpers.inject(ident, content)
  },
  removeStyle: (filePath) => {
    const [fileName, domain] = fileHelpers.valuesFromFilePath(filePath)
    const ident = styleHelpers.idForFileNameDomain(fileName, domain)
    styleHelpers.remove(ident)
  },
}

const fileTypeHandlers = {
  js: (fileName, domain, content) => {
    scriptHelpers.inject(content)
  },
  css: (fileName, domain, content) => {
    const ident = styleHelpers.idForFileNameDomain(fileName, domain)
    styleHelpers.remove(ident)
    styleHelpers.inject(ident, content)
  },
}
