"use strict";

/*
 * Copyright © 2016-2020 Microsoft Corporation
 *
 * PowerLift Remedy bridge
 *
 * This script implements the 'PowerLiftHost' interface that the PowerLift remedies
 * expect to be available at runtime.  It is intended to be injected into the
 * host `WKWebView` before loading the remedy web app.
 *
 * The bridge is responsible for exposing native-code functions to Javascript,
 * e.g. opening the App Store or launching HelpShift.
 */

function _PowerLiftHost(window) {
    this._window = window;
};

_PowerLiftHost.prototype._post = function(payload) {
    this._window.webkit.messageHandlers.bridge.postMessage(payload);
};

/*
 * 'invokeCapability' is the entry-point from the remedy application
 * into this bridge.  Its sole argument is a JSON-encoded object containing
 * the message type and its parameters.
 *
 * At present, the only implemented message type is 'use_capability'.
 */
_PowerLiftHost.prototype.invokeCapability = function(json) {
    var message;
    try {
        message = JSON.parse(json);
    } catch (e) {
        console.error('Invalid JSON: ' + json);
        return;
    }

    if (message === null || typeof message !== 'object') {
        console.error('Invalid message: ' + json);
        return;
    }

    if (! message.hasOwnProperty('messageType')) {
        console.error('Message does not have a type: ' + json);
        return;
    }

    switch (message['messageType']) {
        case 'use_capability':
            if (! message.hasOwnProperty('capability')) {
                console.error('Missing capability: ' + json);
                return;
            }

            if (! message.hasOwnProperty('props')) {
                console.error('Missing props: ' + json);
                return;
            }

            this._post(message);
            break;

        default:
            console.error('Unexpected message type: ' + message['messageType']);
            break;
    }
};

window.PowerLiftHost = new _PowerLiftHost(window);
